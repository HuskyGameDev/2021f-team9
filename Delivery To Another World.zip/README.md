# 2021f-team9
Title:
Delivery to Another World

Description:
Ethan is killed by an Amazon package and wakes up in a fantasy world where everyone is 2D. 
He is helped by a thieves guild to acclimate to this new world, however soon he realizes 
that he is the only one able to turn to face a different plane, making him invisible to 
everyone else, and everyone else invisible to him. Ethan will go on quests for the thieves 
guild, stealing items that will help him on his way to get your revenge on the king of the 
land who reminds him a little too much of the CEO of Amazon from our world...

Game Controls:
WASD to move
Mouse to interact with buttons
Left Shift to sprint
R to rotate 
E to interact
Tab to see map
Escape to pause

Installation:
Make sure to unzip the entire file

Team Members:
Ethan Wright - Team Leader, Artist, Programmer
Bradon Hosang - Artist, Programmer
Nicole Wiszowaty - Artist, Programmer
Rachel Hartrick - Artist Programmer
Rowdy Vyverberg - SFX Designer
Sage Moser - Music Designer
Ethan Fournier - Manager, Distracter, Pizza Eater